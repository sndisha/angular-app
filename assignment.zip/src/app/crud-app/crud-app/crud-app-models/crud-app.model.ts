export interface ProductDetails {
  productName: string,
  productId: string,
  productCount: number,
  productIsAvailable: boolean
  productDescription: any
}

